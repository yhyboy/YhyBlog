﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebPage.Test
{
    public class Map2
    {
     
        public string S2 { get; set; }
        public string S6 { get; set; }
        public string S3 { get; set; }
    }
}